from typing import Tuple, Union

import pygame


def ensure_valid_color(value, parameter_name: str) -> None:
    """Raises a student-friendly ValueError for colors pygame cannot render.

    Accepts exactly the values pygame accepts (named colors like 'red',
    RGB/RGBA tuples and lists, grayscale ints). `None` is allowed because
    several color attributes use it to disable rendering.
    """
    if value is None or isinstance(value, pygame.Color):
        return
    try:
        if isinstance(value, str):
            pygame.Color(value)
        elif isinstance(value, (tuple, list)):
            pygame.Color(*value)
        elif isinstance(value, int) and not isinstance(value, bool):
            pygame.Color(value, value, value)
        else:
            return
    except (ValueError, TypeError):
        raise ValueError(
            f"{parameter_name} must be a color like (255, 0, 0) or 'red', "
            f"got {value!r}\nTry: {parameter_name} = (255, 0, 0)"
        )


class Color:
    """Represents an RGB or RGBA color as a tuple of float values."""

    def __init__(self, value: Tuple[float, ...]) -> None:
        """
        Initialize a Color object with an RGB or RGBA tuple.

        Args:
            value: A tuple of 3 (RGB) or 4 (RGBA) float values.

        Raises:
            ValueError: If the tuple does not have 3 or 4 elements.
        """
        if len(value) not in (3, 4):
            raise ValueError("Color tuple must contain 3 (RGB) or 4 (RGBA) float values.")
        self.color_tuple: Tuple[float, ...] = value

    @classmethod
    def create(cls, value: Union[float, Tuple[float, ...]]) -> "Color":
        """
        Create a Color object from a float or a tuple of floats.

        - Single float → grayscale RGB
        - Tuple with 1 value → grayscale RGB
        - Tuple with 3 values → RGB
        - Tuple with 4 values → RGBA

        Args:
            value: A float or a tuple with 1, 3, or 4 float values.

        Returns:
            A Color object.

        Raises:
            ValueError: If the tuple length is not 1, 3, or 4.
            TypeError: If the input type is invalid.
        """
        if isinstance(value, tuple):
            if len(value) == 1:
                value = (value[0], value[0], value[0])
            elif len(value) not in (3, 4):
                raise ValueError("Tuple must contain 1, 3, or 4 float values.")
        elif isinstance(value, float):
            value = (value, value, value)
        else:
            raise TypeError("Value must be a float or a tuple of 1, 3, or 4 float values.")

        # Convert to floats and validate range
        value = tuple(float(v) for v in value)
        if not all(0 <= v <= 255 for v in value):
            raise ValueError(f"Color values must be 0-255, got {value}")
        return cls(value)

    def get(self) -> Tuple[float, ...]:
        """
        Return the RGB or RGBA tuple representing the color.

        Returns:
            A tuple of 3 or 4 float values representing the color.
        """
        return self.color_tuple
